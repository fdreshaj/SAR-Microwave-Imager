
#include "open_interface.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"
#include <inc/tm4c123gh6pm.h>
#include <stdint.h>
#include "uart-interrupt.h"
#include <stdbool.h>
#include "driverlib/interrupt.h"
#include "open_interface.h"
#define _USE_MATH_DEFINES
#include "movement.h"
#include "navigation (1).h"

#include <stdint.h>
#include"scan (1).h"

//extern volatile int command_ready = 0;
//#define MAX_BUFFER_SIZE 20
//extern volatile char command_buffer[MAX_BUFFER_SIZE];

//int main(){
//    extern char prefix[3];
//
//   // bno_init();
//    timer_waitMillis(700);
//   // bno_t *bno = bno_alloc();
//    uart_interrupt_init();
//    uart_sendStr("\r\nBNO055 IMU ready\r\n");
//    uart_sendStr("--------------------------------------------------\r\n");
//
//    int value = 0;
//    timer_init();
//    int smallest_idx;
//
//     char msg[120];
//    lcd_init();
//    lcd_clear();
//    lcd_printf("UART Interrupt Ready");
//    uart_sendStr("UART Interrupt Ready \n \r");
//
//    right_calibration_value = 248500; //cybot 22
//    left_calibration_value = 1272250;
//    cyBOT_init_Scan(0b0111);
//    cyBOT_Scan_t scan_data;
//
//    oi_t *sensor_data = oi_alloc();
//    oi_init(sensor_data);
int main() {
    extern char prefix[3];
    int obj_count;
   detected_obj_t objects[MAX_OBJECTS];
   int smallest_idx;

    char msg[120];
    // 1. Timer MUST be first � everything else depends on it
    timer_init();
    timer_waitMillis(700);
    // 2. LCD
    lcd_init();
    lcd_clear();
    lcd_printf("Initializing...");

    // 3. UART + clear stale state
    uart_interrupt_init();
    command_ready = 0;
    command_flag  = 0;

    // 4. Scan subsystem init FIRST, then overwrite calibration
    cyBOT_init_Scan(0b0111);
    right_calibration_value = 248500;   // cybot 22
    left_calibration_value  = 1272250;

    // 5. OI last � it takes the longest to init
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);

    uart_sendStr("\r\nReady\r\n");

    while(1){
        //bno_update(bno);

        if(command_ready){

            process_command((char*)command_buffer, prefix, &value);

            if(strcmp(prefix,"000")==0){
                lcd_clear();
                lcd_printf("Moving Forward");
                command_ready=0;

                move_forward(sensor_data, value);
                oi_setWheels(0,0);

                if (sensor_data->bumpLeft || sensor_data->bumpRight)
                            {
                                int bump_r = sensor_data->bumpRight;
                                int bump_l = sensor_data->bumpLeft;
                                nav_bump_avoidance(sensor_data, bump_r, bump_l);
                            }






            }else if (strcmp(prefix, "010") == 0) {
                lcd_clear();
                                lcd_printf("Moving Backward");
                command_ready=0;

                move_backward(sensor_data, value);
                oi_setWheels(0,0);


            } else if (strcmp(prefix, "100") == 0) {
                lcd_clear();
                                lcd_printf("Rotating Right");
                            command_ready=0;

                            turn_right(sensor_data, value);
                            oi_setWheels(0,0);



                        } else if(strcmp(prefix, "110")==0){
                            lcd_clear();
                                            lcd_printf("Rotating left");

                            command_ready=0;

                            turn_left(sensor_data, value);
                             oi_setWheels(0,0);


                        } else if (strcmp(prefix, "001") == 0) {

                            lcd_clear();
                            lcd_printf("Scanning");
                            command_ready=0;
                            uart_sendStr("\r\n=== Scanning... ===\r\n");


                            lcd_clear();
                            lcd_printf("Auto: Scanning...");

                            obj_count = scan_objects(objects, MAX_OBJECTS);
                            print_object_table(objects, obj_count);

                            detected_gap_t gap[9];
                            smallest_idx = find_smallest_linear(objects, obj_count);

                                        if (smallest_idx >= 0)
                                        {
                                            sprintf(msg, "\r\nSmallest: #%d at %.1f deg, %.1f cm "
                                                         "(linear width: %.1f cm)\r\n",
                                                    smallest_idx + 1,
                                                    objects[smallest_idx].center_angle,
                                                    objects[smallest_idx].ping_dist,
                                                    objects[smallest_idx].linear_width);
                                            uart_sendStr(msg);

                                            lcd_clear();
                                            lcd_printf("Target: #%d\n%.0f deg  %.0f cm",
                                                       smallest_idx + 1,
                                                       objects[smallest_idx].center_angle,
                                                       objects[smallest_idx].ping_dist);
                                        }
                                        else
                                        {
                                            uart_sendStr("\r\nNo objects found.\r\n");
                                            lcd_clear();
                                            lcd_printf("No objects found");
                                        }
                                //ANOTHER FUNCTION 0
                        } else if (strcmp(prefix, "101") == 0) {
//                            command_ready=0;
//                            // Accel (raw units: 1 m/s^2 = 100 LSB)
//                            char buf[256];
//                            sprintf(buf,
//                                    "Accel    X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->accel.x, bno->accel.y, bno->accel.z);
//                            uart_sendStr(buf);
//
//                            // Magnetometer (1 uT = 16 LSB)
//                            sprintf(buf,
//                                    "Mag      X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->mag.x, bno->mag.y, bno->mag.z);
//                            uart_sendStr(buf);
//
//                            // Gyroscope (1 dps = 16 LSB)
//                            sprintf(buf,
//                                    "Gyro     X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->gyro.x, bno->gyro.y, bno->gyro.z);
//                            uart_sendStr(buf);
//
//                            // Euler angles (1 deg = 16 LSB)
//                            sprintf(buf,
//                                    "Euler    H=%6d R=%6d P=%6d\r\n",
//                                    bno->euler.heading, bno->euler.roll, bno->euler.pitch);
//                            uart_sendStr(buf);
//
//                            // Quaternion (1 quat = 2^14 LSB)
//                            sprintf(buf,
//                                    "Quat     W=%6d X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->quat.w, bno->quat.x, bno->quat.y, bno->quat.z);
//                            uart_sendStr(buf);
//
//                            // Linear acceleration (gravity removed; 1 m/s^2 = 100 LSB)
//                            sprintf(buf,
//                                    "LinAcc   X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->linacl.x, bno->linacl.y, bno->linacl.z);
//                            uart_sendStr(buf);
//
//                            // Gravity vector (1 m/s^2 = 100 LSB)
//                            sprintf(buf,
//                                    "Gravity  X=%6d Y=%6d Z=%6d\r\n",
//                                    bno->grav.x, bno->grav.y, bno->grav.z);
//                            uart_sendStr(buf);
//
//                            // Temperature (deg C, 1 LSB = 1 deg)
//                            sprintf(buf, "Temp     %d C\r\n", bno->temp);
//                            uart_sendStr(buf);

                            uart_sendStr("--------------------------------------------------\r\n");
                            timer_waitMillis(250);
                            //ANOTHER FUNCTION 1
                    }  else if (strcmp(prefix, "111") == 0) {

                        //ABORT Function
                          break;
                }  else if (strcmp(prefix, "011") == 0) {

                    //ANOTHER FUNCTION 3
            }



                        }

        }

    oi_setWheels(0,0);
        oi_free(sensor_data);

    }
